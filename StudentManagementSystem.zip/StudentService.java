import java.util.*;

public class StudentService {
    private ArrayList<Student> list = new ArrayList<>();

    public void addStudent(Student s) {
        list.add(s);
        System.out.println("Student added successfully!");
    }

    public void viewStudents() {
        if (list.isEmpty()) {
            System.out.println("No students available!");
            return;
        }
        for (Student s : list) {
            System.out.println(s);
        }
    }

    public void searchStudent(int id) {
        for (Student s : list) {
            if (s.getId() == id) {
                System.out.println("Student Found: " + s);
                return;
            }
        }
        System.out.println("Student not found!");
    }

    public void deleteStudent(int id) {
        Iterator<Student> i = list.iterator();
        while (i.hasNext()) {
            Student s = i.next();
            if (s.getId() == id) {
                i.remove();
                System.out.println("Student deleted!");
                return;
            }
        }
        System.out.println("Student not found!");
    }

    public void updateStudent(int id, String name, int age, String course) {
        for (Student s : list) {
            if (s.getId() == id) {
                s.setName(name);
                s.setAge(age);
                s.setCourse(course);
                System.out.println("Student updated!");
                return;
            }
        }
        System.out.println("Student not found!");
    }
}
